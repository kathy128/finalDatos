/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hidalgok
 */
public class Nodo {
  Nodo llink;
   Nodo rlink;
   String info;   

    public void setLlink(Nodo llink) {
        this.llink = llink;
    }

    public void setRlink(Nodo rlink) {
        this.rlink = rlink;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Nodo getLlink() {
        return llink;
    }

    public Nodo getRlink() {
        return rlink;
    }

    public String getInfo() {
        return info;
    }

    public Nodo(Nodo llink, Nodo rlink, String info) {
        this.llink = llink;
        this.rlink = rlink;
        this.info = info;
    }

}
